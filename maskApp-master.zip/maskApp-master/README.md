# FaceDetection Mask App 🤳 

---

Snapchat-like FaceDetection Mask "App" made as a part of CodePen Challenge. Stack: Vue, Camvas, Pico.

---

Online
[@codepen.io/Yasio](https://codepen.io/Yasio/full/MPmvJb/)

### Uses

* vue
* camvas
* pico.js
* sass
